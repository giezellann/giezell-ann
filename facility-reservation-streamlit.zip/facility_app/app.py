import os
import streamlit as st
import pandas as pd
import joblib

from modules.config import MODEL_PATH, METADATA_PATH, DEFAULT_DATA_PATH, ROLES
from modules.data_processing import render_dataset_page
from modules.exploratory_analysis import render_eda
from modules.prediction import render_prediction_page, load_metadata
from modules.dashboard import render_dashboard
from modules.system_design import render_system_design

st.set_page_config(page_title="Facility Reservation Risk System", page_icon="🏫", layout="wide")


@st.cache_resource
def load_model():
    return joblib.load(MODEL_PATH)


@st.cache_data
def load_meta():
    return load_metadata(METADATA_PATH)


@st.cache_data
def load_default_data():
    return pd.read_csv(DEFAULT_DATA_PATH)


if not (os.path.exists(MODEL_PATH) and os.path.exists(METADATA_PATH)):
    st.error("Model files are missing. Make sure models/trained_model.joblib and models/model_metadata.json "
             "are in the repository.")
    st.stop()

model, meta = load_model(), load_meta()

menu = st.sidebar.selectbox("Module", ["Home", "Dataset", "Data Analysis", "Prediction", "Dashboard", "System Design"])
role = st.sidebar.selectbox("Your role (demo)", ROLES)
st.sidebar.caption(f"Model {meta['model_version']} | {meta['algorithm']}")
st.sidebar.caption("Synthetic data only. Predictions support, not replace, human decisions.")

# The dataset chosen on the Dataset page is shared by the EDA and Dashboard pages.
if "df" not in st.session_state:
    st.session_state["df"] = load_default_data()
    st.session_state["df_name"] = "reservations_synthetic.csv (bundled, synthetic)"
df = st.session_state["df"]

if menu == "Home":
    st.title("Campus Facility Reservation Monitoring")
    st.subheader("Predicting cancellation / no-show risk to support facility administrators")
    st.write("This app deploys the model from the Midterm Laboratory Examination (Section A). "
             "It turns predictions into a review workflow where a human makes the final decision.")
    c = st.columns(3)
    c[0].metric("Model", meta["algorithm"])
    c[1].metric("Test ROC-AUC", f"{meta['metrics']['roc_auc']:.3f}")
    c[2].metric("Active records", f"{len(df):,}")
    st.markdown("""
**How to use**
1. **Dataset** - upload a CSV or use the bundled synthetic sample.
2. **Data Analysis** - explore patterns and class balance.
3. **Prediction** - score a single reservation.
4. **Dashboard** - review the High-risk queue and record decisions (Facility Administrator only).
5. **System Design** - requirements, actors, use case diagram and workflow.
""")
    st.warning("Predictions are decision-support outputs, not authorization to reject a reservation or deny services.")
elif menu == "Dataset":
    render_dataset_page(DEFAULT_DATA_PATH)
elif menu == "Data Analysis":
    render_eda(st.session_state["df"])
elif menu == "Prediction":
    render_prediction_page(model, meta)
elif menu == "Dashboard":
    render_dashboard(st.session_state["df"], model, meta, role)
else:
    render_system_design()
