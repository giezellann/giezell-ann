"""Shared constants. Keep in sync with the midterm notebook (Midterm_Lab_Exam_Original.ipynb)."""

TARGET = "cancel_or_noshow"          # 1 = cancelled or no-show, 0 = facility was used
ID_COL = "reservation_id"
DATE_COL = "reservation_date"

# Raw fields known at the prediction checkpoint (the moment a reservation is submitted/approved)
RAW_CATEGORICAL = ["facility_type", "requester_type", "purpose", "day_of_week"]
RAW_NUMERIC = [
    "start_hour", "duration_hours", "lead_time_days", "expected_attendees",
    "prior_reservations", "prior_cancellations", "prior_no_shows", "has_approval_letter",
]
RAW_FEATURES = RAW_CATEGORICAL + RAW_NUMERIC

# Engineered inside add_features() (see data_processing.py)
ENGINEERED = ["is_weekend", "capacity_ratio", "prior_issue_rate"]
MODEL_FEATURES = RAW_FEATURES + ENGINEERED

# Fields that only exist AFTER the reservation date -> leakage, never used for training/inference
LEAKAGE_COLUMNS = ["actual_attendees", "check_in_time", "cancellation_reason", "final_status"]

FACILITY_CAPACITY = {
    "Classroom": 50, "Computer Lab": 40, "AV Room": 80,
    "Gymnasium": 300, "Auditorium": 500, "Sports Court": 100,
}
CATEGORY_VALUES = {
    "facility_type": list(FACILITY_CAPACITY),
    "requester_type": ["Student Organization", "Faculty", "Staff", "Individual Student"],
    "purpose": ["Academic", "Event", "Meeting", "Practice"],
    "day_of_week": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
}
NUMERIC_RANGES = {   # (min, max) used for validation
    "start_hour": (6, 21), "duration_hours": (0.5, 12), "lead_time_days": (0, 120),
    "expected_attendees": (1, 600), "prior_reservations": (0, 200),
    "prior_cancellations": (0, 200), "prior_no_shows": (0, 200), "has_approval_letter": (0, 1),
}

MODEL_PATH = "models/trained_model.joblib"
METADATA_PATH = "models/model_metadata.json"
DEFAULT_DATA_PATH = "data/reservations_synthetic.csv"
USE_CASE_IMG = "assets/use_case_diagram.png"
WORKFLOW_IMG = "assets/decision_workflow.png"

RISK_THRESHOLDS = {"medium": 0.35, "high": 0.60}   # probability cut-offs for the review queue
ROLES = ["Facility Administrator", "Campus Operations Manager", "Requester", "System Administrator"]
