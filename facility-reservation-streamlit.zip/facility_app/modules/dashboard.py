"""Module 4 - Decision-Support Dashboard: KPIs, risk/review queue, interpretation and human follow-up."""
from datetime import datetime
import pandas as pd
import plotly.express as px
import streamlit as st
from modules.config import TARGET, ID_COL, RISK_THRESHOLDS
from modules.data_processing import ensure_id
from modules.prediction import predict_batch

DECISIONS = ["Confirm as booked", "Send reminder / request reconfirmation", "Contact requester and hold waitlist",
             "Release slot to waitlist (after contact)", "Escalate to Operations Manager"]


@st.cache_data
def score(_model, df: pd.DataFrame) -> pd.DataFrame:
    return predict_batch(_model, ensure_id(df))


def interpret(scored: pd.DataFrame) -> list:
    notes = []
    by_fac = scored.groupby("facility_type")["risk_probability"].mean().sort_values(ascending=False)
    notes.append(f"Highest average risk: **{by_fac.index[0]}** ({by_fac.iloc[0]:.0%}); lowest: "
                 f"**{by_fac.index[-1]}** ({by_fac.iloc[-1]:.0%}).")
    high = scored[scored["risk_tier"] == "High"]
    if len(high):
        top_req = high["requester_type"].value_counts().idxmax()
        notes.append(f"{len(high)} reservations are High risk; most are from **{top_req}** requesters.")
        no_letter = (high["has_approval_letter"] == 0).mean()
        notes.append(f"{no_letter:.0%} of High-risk reservations have no approval letter, "
                     "so asking for one at booking time may reduce risk.")
    notes.append("Risk scores are statistical estimates from past patterns. They flag reservations for "
                 "review and must not be used to reject a reservation on their own.")
    return notes


def render_dashboard(df, model, meta, role):
    st.header("Decision-Support Dashboard")
    if df is None or df.empty:
        st.warning("No data loaded. Go to the Dataset page first.")
        return
    from modules.data_processing import validate_schema
    check = validate_schema(df)
    if not check["valid"]:
        st.error("The loaded dataset cannot be scored: " + " ".join(check["errors"]))
        return
    scored = score(model, df)

    # ---- KPIs
    k = st.columns(5)
    k[0].metric("Reservations", f"{len(scored):,}")
    k[1].metric("High-risk", f"{(scored['risk_tier'] == 'High').sum():,}")
    k[2].metric("High-risk share", f"{(scored['risk_tier'] == 'High').mean():.1%}")
    k[3].metric("Avg predicted risk", f"{scored['risk_probability'].mean():.1%}")
    if TARGET in scored.columns and scored[TARGET].notna().any():
        rate = scored[TARGET].mean()
        k[4].metric("Historical utilization", f"{1 - rate:.1%}", help="Share of past reservations actually used")
    else:
        k[4].metric("Historical utilization", "n/a")

    # ---- Charts
    c1, c2 = st.columns(2)
    fac = scored.groupby("facility_type").agg(avg_risk=("risk_probability", "mean"),
                                              high_risk=("risk_tier", lambda s: (s == "High").sum())).reset_index()
    c1.plotly_chart(px.bar(fac, x="facility_type", y="avg_risk", title="Average predicted risk by facility",
                           labels={"avg_risk": "Avg risk"}))
    tiers = scored["risk_tier"].value_counts().reindex(["Low", "Medium", "High"]).fillna(0).reset_index()
    tiers.columns = ["risk_tier", "count"]
    c2.plotly_chart(px.bar(tiers, x="risk_tier", y="count", color="risk_tier", title="Reservations per risk tier",
                           color_discrete_map={"Low": "#4C8C4A", "Medium": "#E0A800", "High": "#B03A2E"}))

    st.subheader("Interpretation")
    for note in interpret(scored):
        st.markdown(f"- {note}")
    st.caption(f"Tier cut-offs: Medium >= {RISK_THRESHOLDS['medium']:.2f}, High >= {RISK_THRESHOLDS['high']:.2f}. "
               f"Model {meta['model_version']} ({meta['algorithm']}).")

    # ---- Review queue
    st.subheader("Risk / review queue")
    f1, f2 = st.columns(2)
    tier_sel = f1.multiselect("Risk tier", ["High", "Medium", "Low"], default=["High"])
    fac_sel = f2.multiselect("Facility", sorted(scored["facility_type"].dropna().unique()))
    queue = scored[scored["risk_tier"].isin(tier_sel)]
    if fac_sel:
        queue = queue[queue["facility_type"].isin(fac_sel)]
    queue = queue.sort_values("risk_probability", ascending=False)
    cols = [c for c in [ID_COL, "reservation_date", "facility_type", "requester_type", "purpose", "day_of_week",
                        "lead_time_days", "risk_probability", "risk_tier", "recommended_followup"] if c in queue.columns]
    st.write(f"{len(queue):,} reservation(s) match. Showing the top 50.")
    st.dataframe(queue[cols].head(50))

    # ---- Human decision (role-gated)
    st.subheader("Record final human decision")
    if "decision_log" not in st.session_state:
        st.session_state["decision_log"] = []
    if role != "Facility Administrator":
        st.info(f"Your role is **{role}**: you can view results, but only a **Facility Administrator** "
                "can record final decisions.")
    elif queue.empty:
        st.info("No reservations in the current queue.")
    else:
        with st.form("decision_form"):
            rid = st.selectbox("Reservation", queue[ID_COL].head(50).tolist())
            decision = st.selectbox("Final decision", DECISIONS)
            reviewer = st.text_input("Reviewer name / ID")
            notes = st.text_area("Notes (reason, contact outcome)")
            submitted = st.form_submit_button("Save decision")
        if submitted:
            if not reviewer.strip():
                st.error("Reviewer name / ID is required so the decision can be audited.")
            else:
                row = scored[scored[ID_COL] == rid].iloc[0]
                st.session_state["decision_log"].append({
                    "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "reservation_id": rid,
                    "risk_probability": row["risk_probability"], "risk_tier": row["risk_tier"],
                    "final_decision": decision, "reviewer": reviewer.strip(), "notes": notes.strip(),
                    "model_version": meta["model_version"]})
                st.success(f"Decision saved for {rid}.")
    log = pd.DataFrame(st.session_state["decision_log"])
    if not log.empty:
        st.markdown("**Decision log (this session)**")
        st.dataframe(log)
        st.download_button("Download decision log (CSV)", log.to_csv(index=False).encode("utf-8"),
                           file_name="decision_log.csv", mime="text/csv")
    st.caption("The decision log is kept in the browser session only. A production system would store it in a database.")
