"""Model loading helpers, single-row inference, batch scoring and risk tiers.
No Streamlit import here so the logic can be unit-tested; app.py wraps load_model with @st.cache_resource."""
import json
from datetime import datetime
import joblib
import numpy as np
import pandas as pd
from modules.config import (MODEL_PATH, METADATA_PATH, NUMERIC_RANGES, FACILITY_CAPACITY, RISK_THRESHOLDS,
                            RAW_FEATURES, CATEGORY_VALUES)
from modules.data_processing import prepare_for_model

ACTIONS = {
    "High": "Facility administrator to call/message the requester, confirm attendance, and hold a waitlist option.",
    "Medium": "Send an automated reminder 48 hours before and ask for reconfirmation.",
    "Low": "No extra action; standard booking confirmation applies.",
}


def load_model(path: str = MODEL_PATH):
    return joblib.load(path)


def load_metadata(path: str = METADATA_PATH) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def risk_tier(prob: float) -> str:
    if prob >= RISK_THRESHOLDS["high"]:
        return "High"
    if prob >= RISK_THRESHOLDS["medium"]:
        return "Medium"
    return "Low"


def validate_inputs(values: dict):
    """Returns (errors, warnings) for a single manual prediction."""
    errors, warnings = [], []
    for col in RAW_FEATURES:
        if values.get(col) in (None, ""):
            errors.append(f"'{col}' is required.")
    if errors:
        return errors, warnings
    for col, (lo, hi) in NUMERIC_RANGES.items():
        v = float(values[col])
        if v < lo or v > hi:
            errors.append(f"'{col}' must be between {lo} and {hi} (got {v}).")
    if float(values["start_hour"]) + float(values["duration_hours"]) > 22:
        errors.append("The reservation must end by 22:00 (start hour + duration exceeds 22).")
    if float(values["prior_cancellations"]) + float(values["prior_no_shows"]) > float(values["prior_reservations"]):
        errors.append("Prior cancellations + no-shows cannot exceed prior reservations.")
    cap = FACILITY_CAPACITY.get(values["facility_type"])
    if cap and float(values["expected_attendees"]) > cap:
        errors.append(f"Expected attendees ({values['expected_attendees']}) exceed the {values['facility_type']} "
                      f"capacity of {cap}.")
    if values["purpose"] == "Academic" and values["requester_type"] == "Individual Student":
        warnings.append("Academic bookings by individual students are rare in the training data; interpret with care.")
    return errors, warnings


def build_input_row(values: dict) -> pd.DataFrame:
    """One-row DataFrame with the exact raw feature names, then the engineered features."""
    row = pd.DataFrame([{c: values[c] for c in RAW_FEATURES}])
    return prepare_for_model(row)


def predict_one(model, values: dict) -> dict:
    X = build_input_row(values)
    label = int(model.predict(X)[0])
    result = {"label": label, "label_text": "Likely cancellation / no-show" if label else "Likely to be used",
              "probability": None, "tier": None, "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
    if hasattr(model, "predict_proba"):
        prob = float(model.predict_proba(X)[0][list(model.classes_).index(1)])
        result["probability"] = prob
        result["tier"] = risk_tier(prob)
        result["action"] = ACTIONS[result["tier"]]
    return result


def predict_batch(model, df: pd.DataFrame) -> pd.DataFrame:
    """Scores a validated dataframe; returns a copy with risk columns added."""
    X = prepare_for_model(df)
    out = df.copy()
    out["predicted_label"] = model.predict(X).astype(int)
    prob = model.predict_proba(X)[:, list(model.classes_).index(1)]
    out["risk_probability"] = np.round(prob, 4)
    out["risk_tier"] = [risk_tier(p) for p in prob]
    out["recommended_followup"] = out["risk_tier"].map(ACTIONS)
    return out


def render_prediction_page(model, meta):
    """Module 3 - Predictive Modeling (Streamlit UI)."""
    import streamlit as st
    import plotly.express as px

    st.header("Predictive Modeling")
    tab_pred, tab_metrics = st.tabs(["Predict a reservation", "Model metrics"])

    with tab_pred:
        st.write("Enter reservation details known **at booking time**. Post-event fields are never used.")
        with st.form("prediction_form"):
            a, b, c = st.columns(3)
            facility = a.selectbox("Facility type", CATEGORY_VALUES["facility_type"])
            requester = b.selectbox("Requester type", CATEGORY_VALUES["requester_type"])
            purpose = c.selectbox("Purpose", CATEGORY_VALUES["purpose"])
            day = a.selectbox("Day of week", CATEGORY_VALUES["day_of_week"])
            start = b.number_input("Start hour (24h)", 0, 23, 9, 1)
            duration = c.number_input("Duration (hours)", 0.5, 24.0, 2.0, 0.5)
            lead = a.number_input("Lead time (days before event)", 0, 365, 7, 1)
            attendees = b.number_input("Expected attendees", 0, 1000, 30, 1)
            letter = c.selectbox("Has approval letter?", ["Yes", "No"])
            prior_res = a.number_input("Prior reservations", 0, 500, 5, 1)
            prior_can = b.number_input("Prior cancellations", 0, 500, 0, 1)
            prior_ns = c.number_input("Prior no-shows", 0, 500, 0, 1)
            go = st.form_submit_button("Predict")
        if go:
            values = {"facility_type": facility, "requester_type": requester, "purpose": purpose,
                      "day_of_week": day, "start_hour": start, "duration_hours": duration,
                      "lead_time_days": lead, "expected_attendees": attendees,
                      "prior_reservations": prior_res, "prior_cancellations": prior_can,
                      "prior_no_shows": prior_ns, "has_approval_letter": 1 if letter == "Yes" else 0}
            errors, warnings = validate_inputs(values)
            for w in warnings:
                st.warning(w)
            if errors:
                for e in errors:
                    st.error(e)
            else:
                res = predict_one(model, values)
                st.subheader(res["label_text"])
                m = st.columns(3)
                if res["probability"] is not None:
                    m[0].metric("Cancel / no-show probability", f"{res['probability']:.1%}")
                    m[1].metric("Risk tier", res["tier"])
                else:
                    m[0].write("This model does not provide probabilities.")
                m[2].metric("Model version", meta["model_version"])
                st.write(f"Prediction timestamp: {res['timestamp']}")
                if res.get("action"):
                    st.info("Suggested human follow-up: " + res["action"])
        st.warning("**Human review required.** This prediction supports, but never replaces, a Facility "
                   "Administrator's decision. It must not be used alone to reject or cancel a reservation.")
        with st.expander("Limitations"):
            for item in LIMITATIONS:
                st.markdown(f"- {item}")

    with tab_metrics:
        st.write(f"**Model:** {meta['algorithm']} | **Version:** {meta['model_version']} | "
                 f"**scikit-learn:** {meta['sklearn_version']}")
        st.write(f"**Target:** `{meta['target']}` | **Checkpoint:** {meta['prediction_checkpoint']}")
        st.write(f"Trained on {meta['trained_on_rows']:,} rows; evaluated on {meta['test_rows']:,} held-out rows. "
                 f"Data: {meta['data_source']}.")
        mt = st.columns(5)
        for col, key in zip(mt, ["accuracy", "precision", "recall", "f1", "roc_auc"]):
            col.metric(key.replace("_", "-").upper(), f"{meta['metrics'][key]:.3f}")
        cm = meta["confusion_matrix"]
        st.plotly_chart(px.imshow(cm, text_auto=True, x=["Pred: used", "Pred: cancel/no-show"],
                                  y=["Actual: used", "Actual: cancel/no-show"], title="Confusion matrix (test set)",
                                  color_continuous_scale="Blues"))
        if meta.get("top_features"):
            tf = pd.Series(meta["top_features"]).reset_index()
            tf.columns = ["feature", "importance"]
            st.plotly_chart(px.bar(tf, x="importance", y="feature", orientation="h", title="Top model features"))
        st.caption("Metrics come from the saved midterm notebook; the model is not retrained in the app.")


LIMITATIONS = [
    "Trained on a synthetic dataset; real campus behaviour will differ and the model must be re-validated.",
    "Moderate predictive power (see ROC-AUC): many cancellations are unpredictable (weather, emergencies).",
    "Probabilities are not guarantees; class weighting means they are not calibrated to real-world rates.",
    "Unfamiliar facility types or requesters fall outside the training data and are less reliable.",
    "The model does not know about holidays, exams, or campus-wide events.",
]
