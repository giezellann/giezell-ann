"""Module 5 - SAD Integration: requirements, actors, use case diagram, workflow."""
import os
import pandas as pd
import streamlit as st
from modules.config import USE_CASE_IMG, WORKFLOW_IMG

FUNCTIONAL = [
    ("FR1", "Validate uploaded reservation CSVs (columns, types, ranges, nulls, duplicates) before use.", "Dataset page",
     "Midterm audit found missing values and duplicate rows."),
    ("FR2", "Show descriptive statistics, class distribution and interactive charts of cancellation / no-show patterns.",
     "Data Analysis page", "Class imbalance (~24% positives) and risk differences by facility/requester."),
    ("FR3", "Predict cancellation / no-show probability for a new reservation using the saved midterm pipeline.",
     "Prediction page", "Best CV model selected in the midterm notebook; no retraining on refresh."),
    ("FR4", "Rank reservations into Low / Medium / High risk tiers and list them in a review queue with recommended follow-up.",
     "Dashboard page", "Prior issue rate, missing approval letters and lead time were the strongest drivers."),
    ("FR5", "Allow only a Facility Administrator to record the final decision, with reviewer, notes, timestamp and model version.",
     "Dashboard page", "Predictions are decision support; humans stay accountable."),
]
NON_FUNCTIONAL = [
    ("NFR1", "Performance", "Pages respond within ~3 seconds on the bundled dataset; the model is loaded once with caching."),
    ("NFR2", "Data privacy and security", "Only synthetic or authorized data is deployed; no credentials or student records in the repo."),
    ("NFR3", "Usability and transparency", "Every prediction shows model version, timestamp, limitations and a human-review notice."),
]
ACTORS = pd.DataFrame([
    ["Requester", "Submits reservations in the existing booking system (outside this app); may use the Prediction page as a self-check.", "Prediction (view)", "No"],
    ["Facility Administrator", "Uploads data, reviews the risk queue, contacts requesters.", "All pages", "Yes"],
    ["Campus Operations Manager", "Monitors KPIs and utilization; reviews model performance.", "Data Analysis, Dashboard, System Design (view)", "No (can escalate)"],
    ["System Administrator", "Maintains the model, repository and deployment.", "Dataset, System Design", "No"],
], columns=["Actor", "Responsibility", "Can view", "Records final decision?"])


def render_system_design():
    st.header("System Analysis and Design Integration")
    st.subheader("Functional requirements (evidence-based)")
    st.dataframe(pd.DataFrame(FUNCTIONAL, columns=["ID", "Requirement", "Implemented in", "Evidence from midterm"]))
    st.subheader("Non-functional requirements")
    st.dataframe(pd.DataFrame(NON_FUNCTIONAL, columns=["ID", "Category", "Requirement"]))
    st.subheader("Actors and permissions")
    st.dataframe(ACTORS)
    st.subheader("Updated use case diagram")
    if os.path.exists(USE_CASE_IMG):
        st.image(USE_CASE_IMG)
    else:
        st.error(f"Diagram file not found: {USE_CASE_IMG}")
    st.caption("'Submit reservation request' belongs to the existing booking process; it triggers a score here.")
    st.subheader("Analytical process / decision-support workflow")
    if os.path.exists(WORKFLOW_IMG):
        st.image(WORKFLOW_IMG)
    else:
        st.error(f"Diagram file not found: {WORKFLOW_IMG}")
    st.markdown("**Who decides?** The model only scores and ranks. A Facility Administrator reviews each "
                "High-risk reservation, contacts the requester, and records the final decision. "
                "No reservation is rejected or released automatically.")
