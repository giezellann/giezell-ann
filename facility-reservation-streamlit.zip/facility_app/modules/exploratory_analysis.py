"""Module 2 - Exploratory Data Analysis."""
import pandas as pd
import plotly.express as px
import streamlit as st
from modules.config import TARGET, RAW_NUMERIC, RAW_CATEGORICAL


@st.cache_data
def descriptive_stats(df: pd.DataFrame) -> pd.DataFrame:
    return df.describe(include="all").T


@st.cache_data
def rate_by(df: pd.DataFrame, col: str) -> pd.DataFrame:
    g = df.groupby(col)[TARGET].agg(rate="mean", reservations="count").reset_index()
    g["rate"] = (g["rate"] * 100).round(1)
    return g.sort_values("rate", ascending=False)


def render_eda(df: pd.DataFrame):
    st.header("Exploratory Data Analysis")
    if df is None or df.empty:
        st.warning("No data loaded. Go to the Dataset page and upload a CSV (or use the bundled sample).")
        return
    has_target = TARGET in df.columns
    cat_cols = [c for c in RAW_CATEGORICAL if c in df.columns]
    num_cols = [c for c in RAW_NUMERIC if c in df.columns]

    st.subheader("Descriptive statistics")
    st.dataframe(descriptive_stats(df))

    st.subheader("Class distribution")
    if has_target and df[TARGET].notna().any():
        counts = df[TARGET].map({0: "Used", 1: "Cancelled / No-show"}).value_counts().reset_index()
        counts.columns = ["outcome", "count"]
        c1, c2 = st.columns([1, 1])
        c1.plotly_chart(px.pie(counts, names="outcome", values="count", hole=0.4,
                               title="Share of outcomes"))
        c2.dataframe(counts)
        st.caption("The classes are imbalanced, so accuracy alone can mislead; review precision and recall too.")
    else:
        st.info(f"Column '{TARGET}' is not in this dataset, so class distribution cannot be shown.")

    st.subheader("Interactive charts")
    tab1, tab2, tab3, tab4 = st.tabs(["Risk by category", "Numeric distribution", "Lead time vs prior issues", "Correlation"])
    with tab1:
        if has_target and cat_cols:
            col = st.selectbox("Group by", cat_cols, key="eda_cat")
            data = rate_by(df, col)
            st.plotly_chart(px.bar(data, x=col, y="rate", hover_data=["reservations"],
                                   labels={"rate": "Cancel / no-show rate (%)"},
                                   title=f"Cancellation / no-show rate by {col}"))
        else:
            st.info("Needs the target column and at least one category column.")
    with tab2:
        if num_cols:
            col = st.selectbox("Numeric feature", num_cols, key="eda_num")
            color = TARGET if has_target else None
            plot_df = df.assign(**{TARGET: df[TARGET].astype("category")}) if has_target else df
            st.plotly_chart(px.histogram(plot_df, x=col, color=color, barmode="overlay", opacity=0.7, nbins=30,
                                         title=f"Distribution of {col}"))
    with tab3:
        needed = {"lead_time_days", "prior_cancellations", "prior_reservations"}
        if needed.issubset(df.columns):
            sample = df.dropna(subset=["lead_time_days"]).head(1500)
            sample = sample.assign(prior_issues=sample["prior_cancellations"] + sample.get("prior_no_shows", 0))
            kw = {"color": sample[TARGET].astype(str)} if has_target else {}
            st.plotly_chart(px.scatter(sample, x="lead_time_days", y="prior_issues", opacity=0.5,
                                       labels={"color": TARGET}, title="Lead time vs prior cancellations + no-shows", **kw))
        else:
            st.info("Required columns not available.")
    with tab4:
        numeric = df[num_cols + ([TARGET] if has_target else [])].apply(pd.to_numeric, errors="coerce")
        if numeric.shape[1] >= 2:
            st.plotly_chart(px.imshow(numeric.corr().round(2), text_auto=True, aspect="auto",
                                      title="Correlation matrix (numeric fields)"))
