"""Dataset upload, schema validation, cleaning and feature engineering (reused from the midterm notebook)."""
import pandas as pd
import numpy as np
from modules.config import (RAW_FEATURES, RAW_CATEGORICAL, RAW_NUMERIC, TARGET, LEAKAGE_COLUMNS,
                            CATEGORY_VALUES, NUMERIC_RANGES, FACILITY_CAPACITY, ID_COL)


def add_features(df: pd.DataFrame) -> pd.DataFrame:
    """Identical to add_features() in the midterm notebook. Never uses post-event fields."""
    out = df.copy()
    out["is_weekend"] = out["day_of_week"].isin(["Saturday", "Sunday"]).astype(int)
    cap = out["facility_type"].map(FACILITY_CAPACITY)
    out["capacity_ratio"] = pd.to_numeric(out["expected_attendees"], errors="coerce") / cap
    prior = pd.to_numeric(out["prior_reservations"], errors="coerce").clip(lower=1)
    issues = (pd.to_numeric(out["prior_cancellations"], errors="coerce")
              + pd.to_numeric(out["prior_no_shows"], errors="coerce"))
    out["prior_issue_rate"] = issues / prior
    return out


def read_csv_safely(file):
    """Returns (df, error_message). Never raises for user-facing problems."""
    try:
        df = pd.read_csv(file)
    except pd.errors.EmptyDataError:
        return None, "The file is empty. Please upload a CSV that has a header row and data."
    except pd.errors.ParserError as e:
        return None, f"The file could not be parsed as CSV: {e}"
    except UnicodeDecodeError:
        return None, "The file is not valid UTF-8 text. Please export it again as a CSV (UTF-8)."
    except Exception as e:  # noqa: BLE001 - show a readable message instead of a stack trace
        return None, f"Unexpected error while reading the file: {e}"
    if df.shape[1] == 0 or len(df) == 0:
        return None, "The CSV has no data rows. Please upload a file with at least one reservation."
    return df, None


def validate_schema(df: pd.DataFrame) -> dict:
    """Schema, range and category checks. 'errors' block use of the file; 'warnings' do not."""
    errors, warnings = [], []
    df_cols = [c.strip() for c in df.columns]
    missing = [c for c in RAW_FEATURES if c not in df_cols]
    if missing:
        errors.append("Missing required column(s): " + ", ".join(missing))
    present_leak = [c for c in LEAKAGE_COLUMNS if c in df_cols]
    if present_leak:
        warnings.append("Post-event (leakage) columns found and ignored: " + ", ".join(present_leak))
    if TARGET not in df_cols:
        warnings.append(f"Target column '{TARGET}' not found: class charts and accuracy checks are unavailable.")
    if not missing:
        for col in RAW_NUMERIC:
            conv = pd.to_numeric(df[col], errors="coerce")
            bad_type = int((conv.isna() & df[col].notna()).sum())
            if bad_type:
                errors.append(f"Column '{col}' has {bad_type} non-numeric value(s).")
                continue
            lo, hi = NUMERIC_RANGES[col]
            out_range = int(((conv < lo) | (conv > hi)).sum())
            if out_range:
                warnings.append(f"Column '{col}' has {out_range} value(s) outside the expected range {lo}-{hi}.")
        for col in RAW_CATEGORICAL:
            unseen = sorted(set(df[col].dropna().astype(str)) - set(CATEGORY_VALUES[col]))
            if unseen:
                warnings.append(f"Column '{col}' has unfamiliar categories (model may be less reliable): "
                                + ", ".join(unseen[:5]))
    return {"errors": errors, "warnings": warnings, "missing_columns": missing,
            "leakage_columns": present_leak, "valid": not errors}


def quality_summary(df: pd.DataFrame) -> dict:
    nulls = df.isna().sum()
    nulls = nulls[nulls > 0].rename("null_count").to_frame()
    nulls["null_pct"] = (nulls["null_count"] / len(df) * 100).round(2)
    return {"rows": len(df), "columns": df.shape[1], "null_table": nulls,
            "total_nulls": int(df.isna().sum().sum()), "duplicate_rows": int(df.duplicated().sum())}


def prepare_for_model(df: pd.DataFrame) -> pd.DataFrame:
    """Returns only the columns the saved pipeline was trained on, with correct dtypes."""
    X = df.copy()
    X.columns = [c.strip() for c in X.columns]
    for col in RAW_NUMERIC:
        X[col] = pd.to_numeric(X[col], errors="coerce")
    for col in RAW_CATEGORICAL:
        X[col] = X[col].astype("object")
    X = add_features(X)
    from modules.config import MODEL_FEATURES
    return X[MODEL_FEATURES]


def ensure_id(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    if ID_COL not in out.columns:
        out.insert(0, ID_COL, [f"ROW-{i + 1:05d}" for i in range(len(out))])
    return out


def render_dataset_page(default_path: str):
    """Module 1 - Dataset Upload and Validation (Streamlit UI)."""
    import streamlit as st

    @st.cache_data
    def _load_default(path):
        return pd.read_csv(path)

    st.header("Dataset Upload and Validation")
    st.write("Upload a CSV of reservations, or load the bundled **synthetic** sample. "
             "Required columns: " + ", ".join(RAW_FEATURES) + ".")
    uploaded = st.file_uploader("Upload CSV", type="csv")
    c1, c2 = st.columns(2)
    if c1.button("Use bundled sample dataset"):
        st.session_state["df"] = _load_default(default_path)
        st.session_state["df_name"] = "reservations_synthetic.csv (bundled, synthetic)"
    template = pd.DataFrame(columns=[ID_COL] + RAW_FEATURES)
    c2.download_button("Download blank CSV template", template.to_csv(index=False).encode("utf-8"),
                       file_name="reservation_template.csv", mime="text/csv")

    if uploaded is not None:
        df_up, err = read_csv_safely(uploaded)
        if err:
            st.error(err)
            return
        report_up = validate_schema(df_up)
        if not report_up["valid"]:
            st.error("This file cannot be used. Fix the issues below and upload it again.")
            for e in report_up["errors"]:
                st.error(e)
            return
        st.session_state["df"], st.session_state["df_name"] = df_up, uploaded.name

    df = st.session_state.get("df")
    if df is None:
        st.info("No dataset loaded yet. Upload a CSV or click 'Use bundled sample dataset'.")
        return

    st.success(f"Active dataset: **{st.session_state.get('df_name', 'dataset')}**")
    report = validate_schema(df)
    for w in report["warnings"]:
        st.warning(w)
    q = quality_summary(df)
    m = st.columns(4)
    m[0].metric("Rows", f"{q['rows']:,}"); m[1].metric("Columns", q["columns"])
    m[2].metric("Missing values", f"{q['total_nulls']:,}"); m[3].metric("Duplicate rows", q["duplicate_rows"])
    st.subheader("Data preview")
    st.dataframe(df.head(20))
    st.subheader("Null summary")
    if q["null_table"].empty:
        st.write("No missing values found.")
    else:
        st.dataframe(q["null_table"])
    if q["duplicate_rows"]:
        st.warning(f"{q['duplicate_rows']} duplicate row(s) found. They are kept in the preview but "
                   "should be reviewed before drawing conclusions.")
