# Campus Facility Reservation Monitoring (Streamlit)

Section A - Systems Analysis and Design Final Laboratory Exercise. Deploys the midterm model that predicts
**cancellation / no-show** for facility reservations and shows how predictions support a human-in-the-loop workflow.

**Live app:** `<paste deployed Streamlit URL>` | **Repo:** `<paste GitHub URL>`

## Modules
| Page | What it does |
|---|---|
| Dataset | CSV upload, schema/range checks, preview, null + duplicate summary |
| Data Analysis | Descriptive stats, class distribution, 4 interactive chart tabs |
| Prediction | One-row inference with the saved pipeline, probability, risk tier, model metrics, limitations |
| Dashboard | KPIs, risk/review queue, interpretations, role-gated final-decision log |
| System Design | 5 functional + 3 non-functional requirements, actors, use case diagram, workflow |

## Run locally
```bash
pip install -r requirements.txt
streamlit run app.py
python -m unittest tests.test_logic -v   # logic tests
```

## Structure
`app.py`, `requirements.txt`, `modules/` (config, data_processing, exploratory_analysis, prediction, dashboard, system_design),
`models/trained_model.joblib` + `model_metadata.json`, `assets/` (use case + workflow diagrams), `data/` (synthetic data, test cases),
`notebooks/Midterm_Lab_Exam_Original.ipynb`, `scripts/`, `tests/`.

## Notes
- The model is trained once in the notebook and loaded with `@st.cache_resource`; the app never retrains.
- `scikit-learn` is pinned to the version used to save the joblib file. Re-save the model if you change it.
- Data is **synthetic**. Never commit real student records or secrets.
- Predictions are decision support. A Facility Administrator records the final decision.
