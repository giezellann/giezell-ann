"""Executes app.py page-by-page against a lightweight fake 'streamlit' + 'plotly' (neither is installable offline here).
It catches NameError/KeyError/TypeError and logic bugs in OUR code; it does NOT replace running the real Streamlit app."""
import sys, types, runpy, os
sys.path.insert(0, os.getcwd())

class Stub:
    def __init__(self): self.session_state = {}; self.choice = {"Module": "Home", "Your role (demo)": "Facility Administrator"}
    self_calls = []
    def __getattr__(self, name):                      # any unknown widget/display call -> harmless no-op
        def f(*a, **k): return self
        return f
    def __enter__(self): return self
    def __exit__(self, *a): return False
    def __bool__(self): return True
    sidebar = property(lambda self: self)
    def cache_data(self, *a, **k):
        return a[0] if a and callable(a[0]) else (lambda fn: fn)
    cache_resource = cache_data
    def set_page_config(self, *a, **k): pass
    def selectbox(self, label, options=None, index=0, **k):
        return self.choice.get(label, list(options)[index])
    def multiselect(self, label, options=None, default=None, **k): return default or []
    def number_input(self, label, min_value=None, max_value=None, value=0, *a, **k): return value
    def text_input(self, *a, **k): return "Tester"
    def text_area(self, *a, **k): return "note"
    def button(self, *a, **k): return False
    def download_button(self, *a, **k): return False
    def form_submit_button(self, *a, **k): return True
    def file_uploader(self, *a, **k): return None
    def columns(self, spec, **k): return [self] * (spec if isinstance(spec, int) else len(spec))
    def tabs(self, names): return [self] * len(names)
    def stop(self): raise SystemExit("st.stop() called")

st = Stub()
sys.modules["streamlit"] = st
px = Stub(); plotly = types.ModuleType("plotly"); plotly.express = px
sys.modules["plotly"], sys.modules["plotly.express"] = plotly, px

failures = 0
for page in ["Home", "Dataset", "Data Analysis", "Prediction", "Dashboard", "System Design"]:
    for mod in [m for m in list(sys.modules) if m.startswith("modules.")]:
        del sys.modules[mod]
    st.choice["Module"] = page
    try:
        runpy.run_path("app.py"); print(f"PASS  {page}")
    except Exception as e:
        failures += 1; print(f"FAIL  {page}: {type(e).__name__}: {e}")
print("decision log rows after Dashboard run:", len(st.session_state.get("decision_log", [])))
st.choice["Your role (demo)"] = "Requester"
st.session_state["decision_log"] = []; st.choice["Module"] = "Dashboard"
runpy.run_path("app.py")
print("Requester role can record decision? ->", len(st.session_state["decision_log"]) > 0, "(expected False)")
sys.exit(failures)
