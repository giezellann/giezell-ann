"""Unit tests for Step 9 (verify). Run:  python -m unittest tests.test_logic -v   (from the repo root)"""
import io, os, sys, unittest
import numpy as np, pandas as pd
sys.path.insert(0, os.getcwd())
from modules.config import RAW_FEATURES, MODEL_FEATURES, LEAKAGE_COLUMNS, TARGET
from modules import data_processing as dp
from modules import prediction as pr

MODEL = pr.load_model(); META = pr.load_metadata()
GOOD = {"facility_type": "Classroom", "requester_type": "Faculty", "purpose": "Academic", "day_of_week": "Monday",
        "start_hour": 9, "duration_hours": 2, "lead_time_days": 5, "expected_attendees": 30,
        "prior_reservations": 10, "prior_cancellations": 0, "prior_no_shows": 0, "has_approval_letter": 1}


class TestUploadValidation(unittest.TestCase):
    def test_valid_file(self):
        df, err = dp.read_csv_safely("data/reservations_synthetic.csv")
        self.assertIsNone(err); self.assertTrue(dp.validate_schema(df)["valid"])
    def test_missing_columns(self):
        df = pd.read_csv("data/reservations_synthetic.csv").drop(columns=["lead_time_days", "purpose"])
        r = dp.validate_schema(df)
        self.assertFalse(r["valid"]); self.assertIn("lead_time_days", r["missing_columns"])
    def test_empty_file(self):
        df, err = dp.read_csv_safely(io.StringIO(""))
        self.assertIsNone(df); self.assertIn("empty", err.lower())
    def test_header_only(self):
        df, err = dp.read_csv_safely(io.StringIO(",".join(RAW_FEATURES) + "\n"))
        self.assertIsNone(df); self.assertIn("no data rows", err.lower())
    def test_non_numeric_value(self):
        df = pd.read_csv("data/reservations_synthetic.csv").head(20)
        df["start_hour"] = df["start_hour"].astype(object); df.loc[0, "start_hour"] = "abc"
        self.assertFalse(dp.validate_schema(df)["valid"])
    def test_leakage_columns_flagged_and_excluded(self):
        df = pd.read_csv("data/reservations_synthetic.csv")
        self.assertEqual(set(dp.validate_schema(df)["leakage_columns"]), set(LEAKAGE_COLUMNS))
        self.assertTrue(set(LEAKAGE_COLUMNS).isdisjoint(dp.prepare_for_model(df).columns))
    def test_null_and_duplicate_summary(self):
        q = dp.quality_summary(pd.read_csv("data/reservations_synthetic.csv"))
        self.assertGreater(q["duplicate_rows"], 0); self.assertGreater(q["total_nulls"], 0)


class TestPredictionInputs(unittest.TestCase):
    def test_valid_input(self):
        e, _ = pr.validate_inputs(GOOD); self.assertEqual(e, [])
    def test_invalid_inputs_rejected(self):
        for change in [{"start_hour": 30}, {"start_hour": 21, "duration_hours": 3},
                       {"expected_attendees": 500}, {"prior_cancellations": 20},
                       {"lead_time_days": -3}, {"purpose": None}]:
            e, _ = pr.validate_inputs({**GOOD, **change}); self.assertTrue(e, change)
    def test_one_row_has_exact_training_features(self):
        X = pr.build_input_row(GOOD)
        self.assertEqual(list(X.columns), MODEL_FEATURES); self.assertEqual(len(X), 1)
    def test_probability_and_tier(self):
        r = pr.predict_one(MODEL, GOOD)
        self.assertIn(r["label"], (0, 1)); self.assertTrue(0 <= r["probability"] <= 1)
        self.assertIn(r["tier"], ("Low", "Medium", "High"))
    def test_riskier_case_scores_higher(self):
        risky = {**GOOD, "requester_type": "Individual Student", "purpose": "Event", "day_of_week": "Saturday",
                 "lead_time_days": 60, "has_approval_letter": 0, "prior_reservations": 5, "prior_cancellations": 3,
                 "prior_no_shows": 2, "facility_type": "Sports Court", "expected_attendees": 10}
        self.assertGreater(pr.predict_one(MODEL, risky)["probability"], pr.predict_one(MODEL, GOOD)["probability"])


class TestConsistencyWithMidterm(unittest.TestCase):
    def test_app_matches_notebook_predictions(self):
        cases = pd.read_csv("data/test_cases.csv")
        raw = cases[RAW_FEATURES]
        scored = pr.predict_batch(MODEL, raw)
        self.assertTrue(np.allclose(scored["risk_probability"], cases["notebook_probability"], atol=1e-4))
        self.assertTrue((scored["predicted_label"].values == cases["notebook_label"].values).all())
    def test_metadata_matches_model_features(self):
        self.assertEqual(META["features"], MODEL_FEATURES); self.assertEqual(META["target"], TARGET)
    def test_no_target_or_leakage_in_features(self):
        self.assertNotIn(TARGET, MODEL_FEATURES); self.assertTrue(set(LEAKAGE_COLUMNS).isdisjoint(MODEL_FEATURES))


if __name__ == "__main__":
    unittest.main(verbosity=2)
