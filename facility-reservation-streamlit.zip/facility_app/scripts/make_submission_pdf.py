import json
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import cm
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak, KeepTogether)
from PIL import Image as PILImage

meta = json.load(open("models/model_metadata.json")); sp = json.load(open("docs/sample_predictions.json"))
ss = getSampleStyleSheet()
H1 = ParagraphStyle("H1", parent=ss["Heading1"], fontSize=15, textColor=colors.HexColor("#1F3A5F"), spaceBefore=8)
H2 = ParagraphStyle("H2", parent=ss["Heading2"], fontSize=11.5, textColor=colors.HexColor("#355C7D"))
B = ParagraphStyle("B", parent=ss["BodyText"], fontSize=9.5, leading=13)
S = ParagraphStyle("S", parent=B, fontSize=8.5, leading=11)
PH = ParagraphStyle("PH", parent=B, textColor=colors.HexColor("#B03A2E"))

def P(t, s=B): return Paragraph(t, s)
def tbl(data, widths, head=True, fs=8.5):
    data = [[P(str(c), S) if not hasattr(c, "wrap") else c for c in r] for r in data]
    t = Table(data, colWidths=widths, repeatRows=1 if head else 0)
    st = [("GRID", (0, 0), (-1, -1), .4, colors.grey), ("VALIGN", (0, 0), (-1, -1), "TOP"),
          ("LEFTPADDING", (0, 0), (-1, -1), 4), ("RIGHTPADDING", (0, 0), (-1, -1), 4)]
    if head: st.append(("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#DCE8F3")))
    t.setStyle(TableStyle(st)); return t
def img(path, w):
    iw, ih = PILImage.open(path).size; return Image(path, width=w, height=w * ih / iw)
def shot_box(label):
    t = Table([[P(f"<b>[Insert screenshot]</b><br/>{label}", S)]], colWidths=[8.4 * cm], rowHeights=[3.4 * cm])
    t.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), .8, colors.HexColor("#B03A2E")), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                           ("ALIGN", (0, 0), (-1, -1), "CENTER")])); return t

doc = SimpleDocTemplate("Final_Lab_Submission_Streamlit_Deployment.pdf", pagesize=A4, leftMargin=2*cm, rightMargin=2*cm,
                        topMargin=1.8*cm, bottomMargin=1.8*cm, title="Final Laboratory Exercise - Streamlit Deployment")
E = []
E += [P("Systems Analysis and Design - Final Laboratory Exercise", H1),
      P("<b>Deploying Midterm Data-Mining Outputs Using Streamlit</b> | Section A: Campus Facility Reservation Monitoring"),
      P("Name: ______________________ &nbsp;&nbsp; Section: A &nbsp;&nbsp; Date: ______________", B), Spacer(1, 6),
      P("Items in <font color='#B03A2E'><b>red</b></font> are for you to fill in after deploying (URLs, your own screenshots, name). "
        "Everything else was generated from the actual repository files and test runs.", S), Spacer(1, 8)]

# 1
E += [P("1. Repository and Deployment Links", H1),
      tbl([["Item", "Link"],
           ["GitHub repository URL", P("[PASTE: https://github.com/&lt;your-username&gt;/facility-reservation-streamlit]", PH)],
           ["Deployed Streamlit URL", P("[PASTE: https://&lt;your-app&gt;.streamlit.app]", PH)],
           ["Entry point / branch", "app.py / main"]], [5*cm, 12*cm])]

# 2
E += [P("2. Original Midterm Notebook and Revised Project Files", H1),
      P("The notebook <b>notebooks/Midterm_Lab_Exam_Original.ipynb</b> is the source of the saved model. Its code trains the pipeline, "
        "writes <i>models/trained_model.joblib</i>, <i>models/model_metadata.json</i> and the 25 fixed test cases used for the consistency check."),
      tbl([["File / folder", "Role"],
           ["app.py", "Navigation (Home, Dataset, Data Analysis, Prediction, Dashboard, System Design), model caching, role selector"],
           ["modules/config.py", "Target, features, leakage list, capacities, risk thresholds"],
           ["modules/data_processing.py", "CSV reading, schema validation, quality summary, add_features(), Dataset page"],
           ["modules/exploratory_analysis.py", "Descriptive stats, class distribution, 4 interactive Plotly chart tabs"],
           ["modules/prediction.py", "Input validation, one-row inference, batch scoring, risk tiers, Prediction page"],
           ["modules/dashboard.py", "KPIs, risk/review queue, interpretation, role-gated decision log"],
           ["modules/system_design.py", "Requirements, actors, use case diagram, workflow"],
           ["models/", "trained_model.joblib, model_metadata.json"],
           ["assets/", "use_case_diagram.png, decision_workflow.png"],
           ["data/", "Synthetic dataset, sample upload files, test_cases.csv"],
           ["tests/", "test_logic.py (15 unit tests), smoke_stub.py"],
           ["requirements.txt, README.md", "Dependencies (scikit-learn pinned to 1.8.0) and documentation"]], [5.2*cm, 11.8*cm])]
E.append(PageBreak())

# 3
E += [P("3. Screenshots", H1), P("3.1 Five working modules (capture from the deployed URL)", H2)]
mods = ["Dataset page: upload a CSV, show validation + null/duplicate summary", "Data Analysis page: class distribution + one interactive chart",
        "Prediction page: filled form with the result visible", "Dashboard page: KPIs, risk queue and decision log",
        "System Design page: requirements, use case diagram, workflow"]
rows = [[shot_box(f"Module {i+1}: {m}"), shot_box(f"Module {i+2}: {mods[i+1]}") if i+1 < len(mods) else ""] for i, m in zip(range(0, 5, 2), mods[::2])]
rows = [[shot_box(f"Module {i+1}: {mods[i]}"), shot_box(f"Module {i+2}: {mods[i+1]}") if i+1 < 5 else ""] for i in (0, 2, 4)]
t = Table(rows, colWidths=[8.6*cm, 8.6*cm]); t.setStyle(TableStyle([("TOPPADDING", (0,0), (-1,-1), 4)])); E.append(t)
E += [Spacer(1, 6), P("3.2 Five sample predictions", H2),
      P("Reproduce each case on the Prediction page and screenshot the result. The values below come from the saved model "
        "(they will match the app, which is checked by the consistency tests). Probabilities are inflated because the model uses balanced class weights.", S)]
cases = sp["cases"]; res = sp["results"]
data = [["#", "Inputs entered (facility, requester, purpose, day, start, lead time, attendees, prior res/can/no-show, letter)", "Probability", "Tier", "Output"]]
for (name, v), r in zip(cases.items(), res):
    inp = (f"{v['facility_type']}, {v['requester_type']}, {v['purpose']}, {v['day_of_week']}, {v['start_hour']}:00 for {v['duration_hours']}h, "
           f"lead {v['lead_time_days']}d, {v['expected_attendees']} pax, prior {v['prior_reservations']}/{v['prior_cancellations']}/{v['prior_no_shows']}, "
           f"letter {'Yes' if v['has_approval_letter'] else 'No'}")
    data.append([name.split(" ")[0], f"<b>{name[3:]}</b><br/>{inp}", f"{r['prob']:.1%}", r["tier"], r["label"]])
E += [tbl(data, [1*cm, 8.6*cm, 2*cm, 1.5*cm, 3.9*cm]), Spacer(1, 4),
      P("[Insert the five Prediction-page screenshots below or attach as Appendix A]", PH)]
E.append(PageBreak())

# 4
E += [P("4. Updated Requirements, Use Case Diagram and Decision-Support Workflow", H1), P("4.1 Functional requirements (evidence-based)", H2),
      tbl([["ID", "Requirement", "Implemented in", "Evidence"],
           ["FR1", "Validate uploaded CSVs (columns, types, ranges, nulls, duplicates).", "Dataset", "Midterm audit found nulls and duplicates (8 duplicate rows, 20 nulls in the sample)."],
           ["FR2", "Show statistics, class distribution and interactive charts.", "Data Analysis", "~24% positive class; risk varies by facility and requester."],
           ["FR3", "Predict cancellation/no-show probability with the saved pipeline.", "Prediction", f"{meta['algorithm']} chosen by 5-fold CV ROC-AUC."],
           ["FR4", "Tier reservations Low/Medium/High and list a review queue with follow-up.", "Dashboard", "Prior issue rate, missing approval letter and lead time drive risk."],
           ["FR5", "Only a Facility Administrator records the final decision (reviewer, notes, timestamp, model version).", "Dashboard", "Predictions are decision support only."]],
          [1.1*cm, 7.2*cm, 2.4*cm, 6.3*cm]),
      P("4.2 Non-functional requirements", H2),
      tbl([["ID", "Category", "Requirement"],
           ["NFR1", "Performance", "Model loaded once with @st.cache_resource; pages respond in ~3 s on the bundled data."],
           ["NFR2", "Privacy / security", "Synthetic or authorized data only; no secrets or student records in the repository."],
           ["NFR3", "Transparency / usability", "Model version, timestamp, limitations and human-review notice shown with each prediction."]],
          [1.3*cm, 3.7*cm, 12*cm]),
      P("4.3 Actors and permissions", H2),
      tbl([["Actor", "Can view", "Records final decision?"],
           ["Requester", "Prediction (self-check)", "No"], ["Facility Administrator", "All pages", "Yes"],
           ["Campus Operations Manager", "Data Analysis, Dashboard, System Design", "No (can receive escalations)"],
           ["System Administrator", "Dataset, System Design; maintains model/deployment", "No"]], [4.5*cm, 8*cm, 4.5*cm]),
      Spacer(1, 6), KeepTogether([P("4.4 Updated use case diagram", H2), img("assets/use_case_diagram.png", 17*cm)]),
      P("'Submit reservation request' belongs to the existing booking process and triggers a score; it is not a page of this app.", S)]
E += [PageBreak(), P("4.5 Decision-support workflow", H2), img("assets/decision_workflow.png", 11.5*cm),
      P("The model scores and ranks. A Facility Administrator reviews High-risk reservations, contacts the requester and records the final decision. "
        "No reservation is rejected or released automatically.", B)]
E.append(PageBreak())

# 5
m = meta["metrics"]
E += [P("5. Short Deployment Report", H1), P("5.1 Reused code", H2),
      P("The data-loading, cleaning, leakage removal, <font face='Courier'>add_features()</font>, preprocessing "
        "(median/most-frequent imputation, scaling, one-hot encoding) and model-comparison code come from the midterm notebook. "
        "The notebook's fitted <b>Pipeline(preprocessor + " + meta["algorithm"] + ")</b> is saved with joblib and loaded unchanged by the app. "
        f"Test-set results from the notebook: accuracy {m['accuracy']:.3f}, precision {m['precision']:.3f}, recall {m['recall']:.3f}, "
        f"F1 {m['f1']:.3f}, ROC-AUC {m['roc_auc']:.3f}."),
      P("5.2 Changes made for deployment", H2),
      P("Notebook cells became modules; feature engineering was moved to a function applied before the pipeline (so the joblib file has no custom classes); "
        "the model is cached and never retrained; CSV validation, input-range checks and friendly error messages were added; "
        "the dashboard converts scores into risk tiers, interpretations and recommended human follow-up; and a role-gated decision log was added. "
        "<b>Differences from the original midterm:</b> [WRITE: any differences between your midterm target/features/dataset and this table; "
        "if you used this stand-in notebook, state that the data are synthetic.]", B),
      P("5.3 Tests performed", H2),
      tbl([["Test", "Method", "Result"],
           ["Valid CSV loads and validates", "unit test", "Pass"],
           ["Missing columns detected (lead_time_days, purpose)", "unit test + data/sample_missing_columns.csv", "Pass"],
           ["Empty file and header-only file rejected with a message", "unit test", "Pass"],
           ["Non-numeric value in a numeric column rejected", "unit test", "Pass"],
           ["Leakage columns flagged and excluded from features", "unit test", "Pass"],
           ["Null and duplicate summary", "unit test", "Pass"],
           ["Valid vs invalid prediction inputs (hour, attendees over capacity, impossible history, missing value)", "unit test", "Pass"],
           ["One-row input has exactly the training feature names", "unit test", "Pass"],
           ["App predictions match the notebook on 25 fixed test cases (probability tolerance 1e-4)", "unit test", "Pass"],
           ["All six pages execute; Requester role cannot save decisions", "smoke_stub.py (fake Streamlit)", "Pass"],
           ["Charts render, upload widget works, deployed URL opens", "Manual on deployed app", P("[Record result]", PH)]],
          [8.2*cm, 5.8*cm, 3*cm]),
      P("Automated result: 15 of 15 unit tests passed. The smoke test used a stand-in for Streamlit and Plotly because they could not be installed "
        "in the build environment, so the real app still needs a manual check of charts, widgets and layout.", S),
      P("5.4 Limitations", H2),
      P("&bull; Synthetic data: real campus behaviour will differ and the model must be re-validated before real use.<br/>"
        f"&bull; Moderate predictive power (ROC-AUC {m['roc_auc']:.2f}, precision {m['precision']:.2f}): many alerts are false alarms, so human review is essential.<br/>"
        "&bull; Class-weighted probabilities are not calibrated; do not read them as real-world percentages.<br/>"
        "&bull; No holiday, exam or weather information; unfamiliar categories are less reliable.<br/>"
        "&bull; The decision log lives in the browser session only; production use needs a database and real authentication (the role selector is a demo).", B),
      P("5.5 Reflection", H2),
      P("[WRITE 1-2 short paragraphs in your own words: what was hardest about moving from notebook to app, what you learned about leakage and "
        "keeping the human decision-maker in the workflow, and what you would improve with more time.]", PH)]
doc.build(E); print("PDF built")
