"""Builds notebooks/Midterm_Lab_Exam_Original.ipynb (stand-in for the student's midterm) and executes its code cells
so models/trained_model.joblib, models/model_metadata.json and data/test_cases.csv are produced by the notebook code."""
import json, sys, matplotlib
matplotlib.use("Agg")

cells = []
def md(s): cells.append(("markdown", s))
def code(s): cells.append(("code", s))

md("# Midterm Laboratory Examination - Campus Facility Reservation Monitoring (Section A)\n"
   "**Target:** `cancel_or_noshow` (1 = cancelled/no-show). **Prediction checkpoint:** when the reservation is submitted/approved.\n\n"
   "> Stand-in notebook built on a synthetic dataset. Replace with your own submitted midterm notebook if its target/features differ, and document differences in the report.")
code('''import pandas as pd, numpy as np, json, joblib, sklearn
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split, StratifiedKFold, cross_val_score
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score, roc_auc_score,
                             confusion_matrix, classification_report)
RANDOM_STATE = 42''')
md("## 1. Data loading and audit")
code('''df = pd.read_csv("data/reservations_synthetic.csv")
print(df.shape); print(df.dtypes); print(df.isna().sum()[df.isna().sum() > 0])
print("Duplicates:", df.duplicated().sum())
print(df["cancel_or_noshow"].value_counts(normalize=True))''')
md("## 2. Cleaning and leakage removal\nColumns known only after the event (`actual_attendees`, `check_in_time`, `cancellation_reason`, `final_status`) are dropped.")
code('''LEAKAGE = ["actual_attendees", "check_in_time", "cancellation_reason", "final_status"]
df = df.drop_duplicates().drop(columns=LEAKAGE)
TARGET = "cancel_or_noshow"
CAT = ["facility_type", "requester_type", "purpose", "day_of_week"]
NUM = ["start_hour", "duration_hours", "lead_time_days", "expected_attendees",
       "prior_reservations", "prior_cancellations", "prior_no_shows", "has_approval_letter"]
CAPACITY = {"Classroom": 50, "Computer Lab": 40, "AV Room": 80, "Gymnasium": 300, "Auditorium": 500, "Sports Court": 100}
print(df.shape)''')
md("## 3. Feature engineering")
code('''def add_features(d):
    out = d.copy()
    out["is_weekend"] = out["day_of_week"].isin(["Saturday", "Sunday"]).astype(int)
    out["capacity_ratio"] = pd.to_numeric(out["expected_attendees"], errors="coerce") / out["facility_type"].map(CAPACITY)
    prior = pd.to_numeric(out["prior_reservations"], errors="coerce").clip(lower=1)
    out["prior_issue_rate"] = (pd.to_numeric(out["prior_cancellations"], errors="coerce")
                               + pd.to_numeric(out["prior_no_shows"], errors="coerce")) / prior
    return out

ENG = ["is_weekend", "capacity_ratio", "prior_issue_rate"]
FEATURES = CAT + NUM + ENG
data = add_features(df)
X, y = data[FEATURES], data[TARGET]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, stratify=y, random_state=RANDOM_STATE)
print(X_train.shape, X_test.shape)''')
md("## 4. Model comparison (5-fold CV on the training split only)")
code('''def make_pre():
    num_cols = NUM + ENG
    return ColumnTransformer([
        ("num", Pipeline([("imp", SimpleImputer(strategy="median")), ("sc", StandardScaler())]), num_cols),
        ("cat", Pipeline([("imp", SimpleImputer(strategy="most_frequent")),
                          ("oh", OneHotEncoder(handle_unknown="ignore"))]), CAT)])

candidates = {
    "LogisticRegression": LogisticRegression(max_iter=1000, class_weight="balanced", random_state=RANDOM_STATE),
    "RandomForest": RandomForestClassifier(n_estimators=300, min_samples_leaf=5, class_weight="balanced", random_state=RANDOM_STATE, n_jobs=-1),
    "GradientBoosting": GradientBoostingClassifier(random_state=RANDOM_STATE),
}
cv = StratifiedKFold(5, shuffle=True, random_state=RANDOM_STATE)
cv_scores = {}
for name, est in candidates.items():
    pipe = Pipeline([("pre", make_pre()), ("model", est)])
    cv_scores[name] = cross_val_score(pipe, X_train, y_train, cv=cv, scoring="roc_auc").mean()
    print(f"{name}: CV ROC-AUC = {cv_scores[name]:.4f}")
best_name = max(cv_scores, key=cv_scores.get); print("Selected:", best_name)''')
md("## 5. Final model and evaluation on the held-out test set")
code('''pipeline = Pipeline([("pre", make_pre()), ("model", candidates[best_name])])
pipeline.fit(X_train, y_train)
pred = pipeline.predict(X_test)
proba = pipeline.predict_proba(X_test)[:, 1]
metrics = {"accuracy": accuracy_score(y_test, pred), "precision": precision_score(y_test, pred),
           "recall": recall_score(y_test, pred), "f1": f1_score(y_test, pred), "roc_auc": roc_auc_score(y_test, proba)}
cm = confusion_matrix(y_test, pred)
print({k: round(v, 4) for k, v in metrics.items()}); print(cm); print(classification_report(y_test, pred))''')
md("## 6. Save the fitted preprocessing + model pipeline (do NOT retrain in the app)")
code('''joblib.dump(pipeline, "models/trained_model.joblib")
meta = {
    "model_version": "v1.0-midterm", "algorithm": best_name, "target": TARGET,
    "prediction_checkpoint": "At reservation submission/approval (no post-event fields)",
    "features": FEATURES, "leakage_removed": LEAKAGE, "sklearn_version": sklearn.__version__,
    "trained_on_rows": int(len(X_train)), "test_rows": int(len(X_test)),
    "class_balance_train": {str(k): float(v) for k, v in y_train.value_counts(normalize=True).items()},
    "metrics": {k: round(float(v), 4) for k, v in metrics.items()},
    "confusion_matrix": cm.tolist(), "cv_roc_auc": {k: round(float(v), 4) for k, v in cv_scores.items()},
    "random_state": RANDOM_STATE, "data_source": "Synthetic dataset (data/reservations_synthetic.csv)",
}
json.dump(meta, open("models/model_metadata.json", "w"), indent=2)
# Fixed test cases + the notebook's own predictions, used later to prove the app matches the notebook
cases = X_test.head(25).copy()
cases["notebook_label"] = pred[:25]; cases["notebook_probability"] = np.round(proba[:25], 6)
cases.to_csv("data/test_cases.csv", index=False)''')
md("## 7. Reload check and feature importance")
code('''reloaded = joblib.load("models/trained_model.joblib")
assert np.allclose(reloaded.predict_proba(X_test)[:, 1], proba)
names = reloaded.named_steps["pre"].get_feature_names_out()
est = reloaded.named_steps["model"]
imp = est.feature_importances_ if hasattr(est, "feature_importances_") else np.abs(est.coef_[0])
top = pd.Series(imp, index=names).sort_values(ascending=False).head(10)
print(top)
meta["top_features"] = {k.replace("num__", "").replace("cat__", ""): round(float(v), 4) for k, v in top.items()}
json.dump(meta, open("models/model_metadata.json", "w"), indent=2)''')

def to_nb(cells):
    nb_cells = []
    for kind, src in cells:
        c = {"cell_type": kind, "metadata": {}, "source": src.splitlines(True)}
        if kind == "code":
            c.update({"execution_count": None, "outputs": []})
        nb_cells.append(c)
    return {"cells": nb_cells, "metadata": {"kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
            "language_info": {"name": "python"}}, "nbformat": 4, "nbformat_minor": 5}

json.dump(to_nb(cells), open("notebooks/Midterm_Lab_Exam_Original.ipynb", "w"), indent=1)
ns = {}
for kind, src in cells:
    if kind == "code":
        exec(compile(src, "<nb-cell>", "exec"), ns)
print("NOTEBOOK EXECUTED OK")
