import graphviz

# ---------- Updated use case diagram ----------
g = graphviz.Digraph("usecase", format="png")
g.attr(rankdir="LR", dpi="170", fontname="Helvetica", labelloc="t", label="Updated Use Case Diagram - Facility Reservation Risk Monitoring System", fontsize="16")
g.attr("node", fontname="Helvetica", fontsize="11")
for a in ["Requester\n(Student Org / Faculty / Staff)", "Facility Administrator", "Campus Operations Manager", "System Administrator"]:
    g.node(a, a, shape="box", style="filled,rounded", fillcolor="#FFF4D6", color="#B58900")
with g.subgraph(name="cluster_sys") as s:
    s.attr(label="Streamlit Predictive Decision-Support System", style="rounded", color="#355C7D", fontname="Helvetica")
    ucs = {
        "UC1": "Upload & validate\nreservation CSV", "UC2": "Explore data (EDA)",
        "UC3": "Predict cancellation /\nno-show risk", "UC4": "View KPI & risk\nreview queue",
        "UC5": "Record final human\ndecision", "UC6": "View requirements &\nSAD documentation",
        "UC7": "Maintain model\n& deployment", "UC8": "Submit reservation\nrequest",
    }
    for k, v in ucs.items():
        s.node(k, v, shape="ellipse", style="filled", fillcolor="#E8F1F8", color="#355C7D")
links = {
    "Requester\n(Student Org / Faculty / Staff)": ["UC8"],
    "Facility Administrator": ["UC1", "UC2", "UC3", "UC4", "UC5"],
    "Campus Operations Manager": ["UC2", "UC4", "UC6"],
    "System Administrator": ["UC1", "UC6", "UC7"],
}
for a, ucl in links.items():
    for u in ucl:
        g.edge(a, u, arrowhead="none")
g.edge("UC3", "UC4", label="«include»", style="dashed", fontsize="9")
g.edge("UC4", "UC5", label="«extend»", style="dashed", fontsize="9")
g.edge("UC1", "UC2", label="«include»", style="dashed", fontsize="9")
g.edge("UC8", "UC3", label="«triggers»", style="dashed", fontsize="9")
g.render("assets/use_case_diagram", cleanup=True)

# ---------- Decision-support workflow ----------
w = graphviz.Digraph("flow", format="png")
w.attr(rankdir="TB", dpi="170", fontname="Helvetica", labelloc="t", label="Decision-Support Workflow (prediction informs, a human decides)", fontsize="16")
w.attr("node", fontname="Helvetica", fontsize="11", shape="box", style="filled,rounded", fillcolor="#E8F1F8", color="#355C7D")
steps = [("A", "1. Reservation request submitted\n(or CSV uploaded by administrator)"),
         ("B", "2. Schema & data-quality validation\n(columns, types, ranges, nulls, duplicates)"),
         ("C", "3. Feature preparation\n(leakage fields removed, engineered features added)"),
         ("D", "4. Saved pipeline scores the request\n(probability + risk tier, never retrained)")]
for k, v in steps: w.node(k, v)
w.node("E", "5. Risk tier?", shape="diamond", fillcolor="#FFF4D6", color="#B58900")
w.node("L", "Low:\nstandard confirmation", fillcolor="#E3F4E1", color="#4C8C4A")
w.node("M", "Medium:\nautomated reminder +\nreconfirmation request", fillcolor="#FFF4D6", color="#B58900")
w.node("H", "High:\nadded to administrator review queue", fillcolor="#FBE3E1", color="#B03A2E")
w.node("R", "6. Facility Administrator reviews context\n(call requester, check schedule, waitlist)", fillcolor="#FBE3E1", color="#B03A2E")
w.node("F", "7. FINAL HUMAN DECISION recorded\n(decision, reviewer, notes, timestamp)", fillcolor="#D6EAF8")
w.node("G", "8. Outcome logged -> dashboard KPIs\n-> periodic model review by Operations Manager")
for a, b in [("A", "B"), ("B", "C"), ("C", "D"), ("D", "E")]: w.edge(a, b)
w.edge("E", "L", label="< 0.35"); w.edge("E", "M", label="0.35-0.59"); w.edge("E", "H", label=">= 0.60")
w.edge("H", "R"); w.edge("M", "F"); w.edge("L", "G"); w.edge("R", "F"); w.edge("F", "G")
w.render("assets/decision_workflow", cleanup=True)
print("diagrams done")
