"""Generates the SYNTHETIC reservation dataset (no real student records).
Replace data/reservations_synthetic.csv with your own authorized midterm dataset if you have one."""
import numpy as np, pandas as pd
from pathlib import Path

rng = np.random.default_rng(42)
n = 3000
cap = {"Classroom": 50, "Computer Lab": 40, "AV Room": 80, "Gymnasium": 300, "Auditorium": 500, "Sports Court": 100}
fac = rng.choice(list(cap), n, p=[.28, .14, .14, .14, .10, .20])
req = rng.choice(["Student Organization", "Faculty", "Staff", "Individual Student"], n, p=[.38, .27, .15, .20])
purpose = np.where(req == "Faculty", rng.choice(["Academic", "Meeting"], n, p=[.8, .2]),
          rng.choice(["Academic", "Event", "Meeting", "Practice"], n, p=[.15, .35, .25, .25]))
dow = rng.choice(["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"], n,
                 p=[.17, .17, .17, .17, .16, .11, .05])
start = rng.integers(7, 20, n)
dur = np.round(rng.choice([1, 1.5, 2, 3, 4, 6], n, p=[.2, .15, .3, .15, .12, .08]), 1)
dur = np.minimum(dur, 22 - start)
dur = np.maximum(dur, 1)
lead = np.clip(rng.gamma(2.0, 6.0, n).round(), 0, 90).astype(int)
cap_arr = np.array([cap[f] for f in fac])
att = np.clip((cap_arr * rng.beta(3, 2.2, n)).round(), 2, None).astype(int)
prior_res = rng.poisson(np.where(req == "Individual Student", 2, 8), n)
prior_can = np.array([rng.binomial(p, .14) for p in prior_res])
prior_ns = np.array([rng.binomial(max(p - c, 0), .08) for p, c in zip(prior_res, prior_can)])
letter = (rng.random(n) < np.where(req == "Individual Student", .35, .8)).astype(int)

weekend = np.isin(dow, ["Saturday", "Sunday"]).astype(int)
cap_ratio = att / cap_arr
issue_rate = (prior_can + prior_ns) / np.maximum(prior_res, 1)
logit = (-3.3 + 0.035 * lead + 2.4 * issue_rate + 0.8 * (1 - letter) + 0.55 * weekend
         + 0.6 * (cap_ratio < .35) + 0.35 * (start >= 17) + 0.3 * (dur >= 4)
         + np.select([req == "Individual Student", req == "Student Organization"], [0.7, 0.3], 0.0)
         + np.select([purpose == "Event", purpose == "Practice"], [0.35, 0.25], 0.0)
         + np.select([fac == "Gymnasium", fac == "Sports Court"], [0.3, 0.4], 0.0)
         + rng.normal(0, 0.6, n))
p = 1 / (1 + np.exp(-logit))
y = (rng.random(n) < p).astype(int)

dates = pd.to_datetime("2025-08-01") + pd.to_timedelta(rng.integers(0, 300, n), unit="D")
df = pd.DataFrame({
    "reservation_id": [f"RSV-{i:05d}" for i in range(1, n + 1)], "reservation_date": dates.strftime("%Y-%m-%d"),
    "facility_type": fac, "requester_type": req, "purpose": purpose, "day_of_week": dow,
    "start_hour": start, "duration_hours": dur, "lead_time_days": lead, "expected_attendees": att,
    "prior_reservations": prior_res, "prior_cancellations": prior_can, "prior_no_shows": prior_ns,
    "has_approval_letter": letter, "cancel_or_noshow": y,
})
# Leakage columns: only known AFTER the event. They are in the raw file on purpose, to be removed in Step 1.
df["actual_attendees"] = np.where(y == 1, 0, (att * rng.uniform(.5, 1.0, n)).round().astype(int))
df["check_in_time"] = np.where(y == 1, "", [f"{h:02d}:{m:02d}" for h, m in zip(start, rng.integers(0, 15, n))])
df["cancellation_reason"] = np.where(y == 1, rng.choice(["Schedule conflict", "Weather", "Event cancelled", "No show"], n), "")
df["final_status"] = np.where(y == 1, "Cancelled/No-show", "Completed")
# a few realistic data-quality problems to exercise validation
idx = rng.choice(n, 25, replace=False); df.loc[idx[:12], "lead_time_days"] = np.nan
df.loc[idx[12:20], "purpose"] = np.nan
df = pd.concat([df, df.sample(8, random_state=1)], ignore_index=True)   # 8 duplicate rows
Path("data").mkdir(exist_ok=True)
df.to_csv("data/reservations_synthetic.csv", index=False)
print(df.shape, "cancel/no-show rate:", round(df.cancel_or_noshow.mean(), 3))
